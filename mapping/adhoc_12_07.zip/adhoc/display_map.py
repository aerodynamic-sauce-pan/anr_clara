import argparse
import numpy as np
import pandas as pd
import pylab as pl
import matplotlib.transforms as mtransforms

from time import time
from matplotlib import pyplot as plt

from mapping.adhoc.geometry import get_angle2D, pol2cart


# Unfinished
def plot_tree_map_pol(tree_map, girths, dmax, display_path, display_type):
    """Display a tree map on a radar like map.

    Displays trees position and girth on a polar projected map. Each tree is
    positioned on a depth level line at an angle relative to the 0° line.

    Args:
        tree_map (dictionnary): map of selected trees containing their polar
                                coordinates and girth.
    """
    print(f'Plotting ground truth map...')
    timestamps = tree_map['TimeStamp'].unique()
    print('Unique timestamps : ', len(timestamps))
    fig = plt.figure(figsize=(10, 10))

    for idx, ts in enumerate(timestamps[:1]):
        if idx % 1 == 0:
            ax = pl.subplot(121, projection='polar')
            trans_offset = mtransforms.offset_copy(ax.transData, fig=fig, y=6, units='dots')
            reduced_tree_map = tree_map[(tree_map['TimeStamp'] == ts) &
                                        (tree_map['Distance'] <= dmax)]
            pDrone = (reduced_tree_map.iloc[0]['POS_X'], reduced_tree_map.iloc[0]['POS_Y'])
            pTree = (np.array(reduced_tree_map['LocX'])-np.array(pDrone[0]),
                     np.array(reduced_tree_map['LocY'])-np.array(pDrone[1]))
            for row_i in range(reduced_tree_map.shape[0]):
                girth = girths[girths['Name'] == reduced_tree_map.iloc[row_i]['Name']].iloc[0]['Girth']
                x, y = np.deg2rad(get_angle2D(pDrone, [pTree[0][row_i], pTree[1][row_i]])), reduced_tree_map.iloc[row_i]['Distance']
                x_disp = np.rad2deg(x)

                plt.plot(x, y, 'ro', label='trees')
                plt.text(x, y, '%d, %d\n%.3fm' % (int(x_disp), int(y), girth), transform=trans_offset, horizontalalignment='center', verticalalignment='bottom')
                plt.plot(pDrone[0], pDrone[1], '+b', label='drone')
                plt.text(pDrone[0]+1, pDrone[1]+1, 'Drone', c='b', transform=trans_offset, horizontalalignment='center', verticalalignment='bottom')
                circle = pl.Circle(pol2cart(x, y), girth,
                                   transform=ax.transProjectionAffine + ax.transAxes,
                                   color="red", alpha=0.4)
                ax.add_artist(circle)

            plt.suptitle('Ground truth tree map', fontweight='bold')
            plt.title(f'Drone pos : {pDrone}')
            plt.tight_layout(rect=[0, 0.03, 1, 0.95])

            rlab = plt.ylabel('Distance', labelpad=40, c='blue', fontweight='bold')
            ax.set_rlabel_position(180)
            rlab.set_rotation(90)
            plt.setp(ax.get_yticklabels(), fontweight='bold', c='blue')
            plt.grid(True, c='deepskyblue')

            if not((display_path is None) or (display_type is None)):
                plt.subplot(122)
                if display_type == 'rgb':
                    img = plt.imread(display_path+str(ts)+'_rgb.png')
                elif display_type == 'ss':
                    img = plt.imread(display_path+str(ts)+'_ss.png')
                plt.imshow(img)
            plt.pause(0.001)
            #plt.clf()
    plt.show()


def plot_tree_map_cart(tree_map, girths, dmax, display_path=None, display_type=None):
    """Display a tree map on a radar like map.

    Displays trees position and girth on a polar projected map. Each tree is
    positioned on a depth level line at an angle relative to the 0° line.

    Args:
        tree_map (dictionnary): map of selected trees containing their polar
                                coordinates and girth.
    """
    print(f'Plotting ground truth map...')
    timestamps = tree_map['TimeStamp'].unique()
    print(f'Unique trees : {girths.shape[0]}.')
    print(f'Unique drone pose : {len(timestamps)}.')
    print(f'Unique distances : {tree_map.shape[0]}.')
    
    plt.figure(figsize=(10, 10))
    for idx, ts in enumerate(timestamps[:1]):
        if idx % 1 == 0:
            plt.subplot(121)
            reduced_tree_map = tree_map[(tree_map['TimeStamp'] == ts) &
                                    (tree_map['Distance'] <= dmax)]
            pDrone = (reduced_tree_map.iloc[0]['POS_X'], reduced_tree_map.iloc[0]['POS_Y'])
            pTree = [list(reduced_tree_map['LocX']), list(reduced_tree_map['LocY'])]
            plt.plot(pTree[0], pTree[1], 'ro', label='trees')
            plt.plot(pDrone[0], pDrone[1], '+b')

            plt.text(pDrone[0]+1, pDrone[1]+1, 'Drone', c='b')
            for row_i in range(reduced_tree_map.shape[0]):
                girth = girths[girths['Name'] == reduced_tree_map.iloc[row_i]['Name']]['Girth']
                plt.text(pTree[0][row_i]+1, pTree[1][row_i]+1, '%d, %d\n%.3fm' % (int(pTree[0][row_i]), int(pTree[1][row_i]), girth))
            plt.suptitle('Ground truth tree map', fontweight='bold')
            plt.title(f'Drone pos : {pDrone}')
            plt.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.grid(True, c='deepskyblue')

            if not((display_path is None) or (display_type is None)):
                plt.subplot(122)
                if display_type == 'rgb':
                    img = plt.imread(display_path+str(ts)+'_rgb.png')
                elif display_type == 'ss':
                    img = plt.imread(display_path+str(ts)+'_ss.png')
                plt.imshow(img)
            plt.pause(0.001)
            #plt.clf()
    plt.show()
    

def main(src_dist=None, src_girth=None, dmax=None,
         display_path=None, display_type=None, view='cartesian'):
    print(f'Loading data files...')
    distances = pd.read_csv(src_dist)
    distances[['LocX', 'LocY', 'LocZ']] = distances[['LocX', 'LocY', 'LocZ']]
    distances['Distance'] = distances['Distance']
    girths = pd.read_csv(src_girth)
    if view == 'polar':
        plot_tree_map_pol(distances, girths, dmax, display_path, display_type)
    elif view == 'cartesian':
        plot_tree_map_cart(distances, girths, dmax, display_path, display_type)


if __name__ == '__main__':
    PARSER = argparse.ArgumentParser()
    PARSER.add_argument('-s', '--source',
                        nargs=1,
                        type=str,
                        default='distances.csv',
                        help='Source distances csv file.')
    PARSER.add_argument('-g', '--girth',
                        nargs=1,
                        type=str,
                        default='girth.csv',
                        help='Source girth csv file.')
    PARSER.add_argument('--dmax',
                        nargs='?',
                        type=int,
                        default=np.inf,
                        help='Maximum depth to consider in the scene'
                             '(in meters).')
    PARSER.add_argument('--display_path',
                        nargs=1,
                        type=str,
                        default='rgb',
                        help='Path to images to display next to map.')
    PARSER.add_argument('--display_type',
                        nargs=1,
                        type=str,
                        default='rgb',
                        help='Image type to display next to map (rgb or ss)')
    PARSER.add_argument('--view',
                        nargs='*',
                        type=str,
                        default='polar',
                        help='Cartesian or polar projection.')
    ARGS = PARSER.parse_args()
    main(ARGS.source[0], ARGS.girth[0], ARGS.dmax, 
         ARGS.display_path[0], ARGS.display_type[0], ARGS.view[0])