# Travail
- Récap travail (cf. JdB).

# UE4
- Charles créé un git pour lui et moi et a raffiné son script qui utilise maintenant des Look-Up Tables à la place de blender. Le gain de temps commence à se faire sentir et est encore améliorable.

# Mapping par bitterlich
- Rollback du code durant le WE à cause d'une mauvaise manip de mes éditeurs à distance lors d'une instabilité de connexion : perte de temps lundi pour tout remettre à niveau.
- Echantillonnage des images dans leur profondeur et hauteur + fenêtre glissante sur ces dimensions opérationnelle


# Prochaine réunion
- Jeudi 27/05 matin
