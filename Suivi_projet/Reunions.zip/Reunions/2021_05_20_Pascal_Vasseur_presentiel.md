# Travail
- Récap travail (cf. JdB).

# UE4
- Mondes synchronisés avec Charles et captures OK niveau luminosité

# Mapping par bitterlich
- Développement en cours
	- Echantillonnage sur la profondeur et hauteur faits
	- Echantillonnage sur la largeur + génération cartes à venir


# Prochaine réunion
- Mardi 25/05 : heure à préciser
