# Point milieu de semaine
Pour l'instant pas de budget Pasal verra vec Christophe et les chercheurs.

## Datasets vidéos

Jusqu'à présent, utilisé des images plustot que des séquences car limitation matérielle.
On aura tjrs besoin d'une init donc -> image ok. Mais des séquences sont mieux adaptées.

On oublie la contrainte de la légèrete de l'embarqué car peu de chance qu'on finisse le projet cette année. On focus sur qualité de reconstrution et précision;
