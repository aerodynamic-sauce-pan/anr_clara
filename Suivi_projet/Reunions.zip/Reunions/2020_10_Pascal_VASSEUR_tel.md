# Sujet
ANR : Agence nationale de la recheche (INRIA/CNRS + CNR)
Stéphane Canu impliqué dans le projet sur un autre aspect

Idée : drone avec GPS down qui navigue SOUS les arbres -> naviguer d'un point A à B
Explorer méthodes à base de réseaux de neurones, mais plutot que end-to-end-> découper les tâches classiquement.

Obj = construire une carte basé sur les arbres. Le drone a des capacités limités -> se baser que sur les arbres en supposant qu'il  a assez d'aléatoire dans la nature


Fait :
1. détection des arbres via CNN. (code non contrôlé -> à reprendre)
2. estimation profondeur arbres pour construire carte
3. (optionnel) incertitude sur les élem sur carte : comment gérer l'incertitude via NN

# Aboutissement
Sujet purement académique. Peut etre surveillance départ d'incendie ?

# Orga
## Stage
Relations proposées =  possible. + probable = Autriche Université reconnue. Utile pour thèse -> échanges, déplacements...
Solution : faire naître des relations au Canada ou ailleurs.

## Thèse
Pas de financement pour l'instant, need monter un dossier sachant qu'on a besoin présenter :

- encadrement
- sujet
- candidat

Incertitude : peut ne pas aboutir

Heures enseignement possibles : contrats doctoraux (64h max)

Comité de suivi : 1 prez à la fin de chaque année. Le comité peut donner des pistes et estimer s'il faut arrêter. Une personne de la DGA en suivi car contributeur.


Pour monter le dossier : dépôt d'intention mois de février et dépôt de dossier au mois d'Avril (l'an dernier). ~2 mois

Dossier financement thèse =/= stage. Thèse = caméra à événements => porter à omnidirectionnel.

# Réponse
Autre candidat le 5 nov. Donner réponse courant/fin novembre.
