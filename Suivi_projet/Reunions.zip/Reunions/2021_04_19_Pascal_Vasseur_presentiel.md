# Travail
- Récap travail (cf. JdB).

## Réu avec Charles
- Optimal : partager les données equi de Charles voire son code pour gagner du temps (donner accès au travail de Dao en retour)

## 360SD-Net
- Présentation des résultats moyens sur de simages du net + d'UE4
- Comprendre en détail ce qu'est l'entrée Polar Angle + leur concatenation + ASPP
	- Si pas possible juste à partir du papier : demander les données

# Réunion
- Lundi 26/04