# Travail
- Récap' de ce qu'il s'est passé
	- Installation GPU et UE4 + unrealcv
	- Problèmes train en cours de correction avec Dao
	- A l'avenir : transfert environnement dev sur machine GPU
- Confirmation générer data stereo pertinent
	- Caméra perspectives classique, basique 20cm baseline, axe parallèle
	- Puis regarder les méthodes d'estimation, dans un premier temps géométriques sur images 2D puis apprentissage sur 2D puis 3D
	- Voir sur [Paper with code](https://paperswithcode.com/)
		- [360SD-Net:  360°Stereo  Depth  Estimation  with  Learnable  Cost  Volume](https://arxiv.org/pdf/1911.04460v2.pdf)
		- [Revisiting Stereo Depth Estimation From a Sequence-to-Sequence Perspectivewith Transformers](https://arxiv.org/pdf/2011.02910v2.pdf)
- Améliorer instanciation sera bien une fosi qu'on aura la fusion depth/seg sem

# Deadlines
- Pascal en présentiel Vendredi 13h-14h puis en réunion après
- La semaine pro : générer data stereo + trouver des méthodes qui donnent des res.

# Organisation
- Confinement : Rien n'a changé au niveau de l'université
- Avec compte UPJV : on peut accéder à certains papier (voir 'science directe')
