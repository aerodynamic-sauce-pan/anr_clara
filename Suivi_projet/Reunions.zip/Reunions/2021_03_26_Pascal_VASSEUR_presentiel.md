# Travail
- L'histoire de UE4 et GPU
- Changement de poste
- Entrainement marche

- Articles : voir comment synchroniser la géométrie épipolaire des cams (guillaume aurait peut etre des élem de réponse si pas dans le papier)
	- Ré-échantillonage de la sphère pour évaluer les distances points entre points ? -> ré-échantillonage ? interpol ? Possible de faire sans ?

- Voir sur UE4 pour générer des images fisheye
	- Pour le modèle : représentation déformée "equirectangulaire" (même que le papier)

- Programme : générer dataset fisheye et tenter la seg sem dessus : si nul on focus sur img projection

# Deadlines


# Organisation
- S'organiser entre nous pour les demi-journées de présence
