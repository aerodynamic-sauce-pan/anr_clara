# Travail
- Récap travail (cf. JdB)

## UE4
- Réussir à générer dataset equirectangular UE4 de foret pour tester direct avec les paramètres frozen de l'article fisheye. Partie synchronisation d'acquisition à définir. A voir avec les partenaires du projet qui eux ont déjà des configs avec des thetas définis.

## Article fisheye
- Grille de calibration Aprilgrid : voir côté openCV ou Scaramusa.
- Voir si le modèle tient toujours le coup avec beaucoup d'objets proches.
- Faire recherche sur les possibilité d'outils de synchronisation des cam Ricoh modèles theta, car pas d'indication dans l'article.

## Autre
- Si on génère des images perspectives -> se tourner vers d'autre méthodes directes établies plutôt que d'essayer de modifier la méthode de l'article fisheye.
- Tenter une fusion de données si l'estimation de profondeur sur nos jeux de données synthetiques est un succès


